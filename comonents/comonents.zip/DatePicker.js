import React from "react";
import DatePicker from "react-datepicker";
import { Container, Row, Col } from 'react-grid-system';

 
import "react-datepicker/dist/react-datepicker.css";
 
// CSS Modules, react-datepicker-cssmodules.css
// import 'react-datepicker/dist/react-datepicker-cssmodules.css';
 
class DateSelector extends React.Component {
  state = {
    startDate: new Date()
  };
 
  handleChange = date => {
    this.setState({
      startDate: date
    });
  };
 
  render() {
    return (
       <div>
        <DatePicker
            selected={this.state.startDate}
            onChange={this.handleChange}/>

        <Container>
            <Row>
                <Col sm={4}>One of three columns</Col>
                <Col sm={4}>One of three columns</Col>
                <Col sm={4}>One of three columns</Col>
            </Row>
        </Container>
    </div> 
    );
  }
}

export default DateSelector;